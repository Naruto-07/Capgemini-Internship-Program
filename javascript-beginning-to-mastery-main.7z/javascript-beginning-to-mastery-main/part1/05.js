// declare constants 

const pi = 3.14;
console.log(pi);