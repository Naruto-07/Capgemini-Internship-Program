// trim() 
// toUpperCase()
// toLowerCase()
// slice()

let firstName = "harshit";

// String is immutable.

// console.log(firstName.length);=> use to find the length of string
// firstName = firstName.trim(); // "harshit" =>trim all the spaces
// console.log(firstName)

// console.log(firstName.length);

// firstName = firstName.toUpperCase();=> Convert all character into uppercase 

// firstName = firstName.toLowerCase();=> Convert all character into lower case
// console.log(firstName);

// start index 
// end index

let newString = firstName.slice(1); // hars
newString=firstName.slice(2,5);
console.log(newString);