"use strict";
// => Restrict to do Mistake 

// intro to variables

// variables can store some information
// we can use that information later
// we can change that information later

// declare a variable 

var firstName = "Devesh";

// use a variable 
console.log(firstName);

// change value 

firstName = "Kumar";

console.log(firstName);
// Case Sensitive