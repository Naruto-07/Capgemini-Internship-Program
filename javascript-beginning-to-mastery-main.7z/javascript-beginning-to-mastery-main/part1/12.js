// booleans & comparison operator 

// booleans -> true, false 

let num1 = 7;
let num2 = "7";

//Comparison Operator

console.log(num1<num2);

// == vs === 
console.log(num1 === num2);  // this will check value and datatype

// != vs !==

console.log(num1 !== num2);
