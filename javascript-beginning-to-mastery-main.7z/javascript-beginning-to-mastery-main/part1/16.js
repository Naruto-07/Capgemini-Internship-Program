// and  or operator 

let firstName = "arshit";
let age = 16;

if(firstName[0] === "H"){
    console.log("your name starts with H")
}

if(age > 18){
    console.log("you are above 18");
}
// AND Operator 
if(firstName[0] === "H" && age>18){
    console.log("Name starts with H and above 18");
}else{
    console.log("inside else");
}

// OR Operator
if(firstName[0] === "H" || age>18){
    console.log("inside if");
}else{
    console.log("inside else");
}