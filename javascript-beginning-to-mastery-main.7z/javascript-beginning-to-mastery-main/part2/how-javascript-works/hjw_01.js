// compilation 
// code execution

// why compilation 


// How javascript code executes 


// what is global exection context ? 
// what is local execution context ? 
// closures
console.log(this);
console.log(window);
console.log(firstName);
var firstName = "Harshit";
console.log(firstName);